// Copyright 2016, Bruno Terkaly, All Rights Reserved
package com.terkaly.JavaMongoDB;

public class Rating {
    public Rating(int numberratings, int averagerating) {
        super();
        this.numberratings = numberratings;
        this.averagerating = averagerating;
    }
    private int numberratings;
    private int averagerating;
}
